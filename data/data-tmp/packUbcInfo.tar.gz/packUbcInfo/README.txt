########################################################
### get info from ubc 
### use pipe
### eg. cat daxing_cure.dat | python infoQuery.py
###################################################
